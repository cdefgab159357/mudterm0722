<?php
include('connect.php');

if (isset($_POST["create"])) {
    $product_name = mysqli_real_escape_string($conn, $_POST["product_name"]);
    $product_type = mysqli_real_escape_string($conn, $_POST["product_type"]);
    $product_price = mysqli_real_escape_string($conn, $_POST["product_price"]);
    $product_num = mysqli_real_escape_string($conn, $_POST["product_num"]);
    $product_desc = mysqli_real_escape_string($conn, $_POST["product_desc"]);
    $product_picname = $_FILES["product_pic"]['name'];

    // 文件上傳處理
    if (isset($_FILES["product_pic"]) && $_FILES["product_pic"]["error"] == 0) {
        $target_dir = __DIR__ . "/uploads/";
        $target_file = $target_dir . basename($_FILES["product_pic"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // 檢查文件是否為圖像
        $check = getimagesize($_FILES["product_pic"]["tmp_name"]);
        if ($check === false) {
            die("檔案不是圖片。");
        }

        // 檢查文件大小
        if ($_FILES["product_pic"]["size"] > 5000000) {
            die("抱歉，您的文件太大。");
        }

        // 允許的文件格式
        $allowed_formats = array("jpg", "jpeg", "png", "gif", "jfif");
        if (!in_array($imageFileType, $allowed_formats)) {
            die("抱歉，只允許 JPG, JPEG, PNG, GIF 和 JFIF 文件。");
        }

        // 嘗試移動上傳的文件
        if (move_uploaded_file($_FILES["product_pic"]["tmp_name"], $target_file)) {
            $product_pic = $target_file;
        } else {
            die("抱歉，上傳您的文件時出錯。");
        }
    } else {
        die("沒有上傳文件或上傳文件時出錯。");
    }

    // 插入資料庫
    $sqlInsert = "INSERT INTO books (product_name, product_type, product_price, product_num, product_desc, product_pic) VALUES ('$product_name', '$product_type', '$product_price', '$product_num', '$product_desc', '$product_picname')";

    if (mysqli_query($conn, $sqlInsert)) {
        session_start();
        $_SESSION["create"] = "商品添加成功！";
        header("Location: index_pro.php");
    } else {
        die("出錯了: " . mysqli_error($conn));
    }
}
?>