<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <title>ADD Product</title>
</head>

<body>
    <div class="container my-5">
        <header class="d-flex justify-content-between my-4">
            <h1>ADD Order</h1>
            <div>
                <a href="index_pro.php" class="btn btn-primary">Back</a>
            </div>
        </header>

        <form action="pro-add-api.php" method="post" enctype="multipart/form-data">

            <div class="form-element my-4">
                <label for="product_name" class="form-label">商品名稱</label>
                <input type="text" class="form-control" name="product_name">
            </div>

            <div class="form-element my-4">
                <label for="product_type" class="form-label">商品類型</label>
                <select name="product_type" id="" class="form-control">
                    <option value="">Select Book Type:</option>
                    <option value="商品A">商品A</option>
                    <option value="商品B">商品B</option>
                    <option value="商品C">商品C</option>
                    <option value="商品D">商品D</option>
                </select>
            </div>

            <div class="form-element my-4">
                <label for="product_price" class="form-label">商品價格</label>
                <input type="text" class="form-control" name="product_price">
            </div>

            <div class="form-element my-4">
                <label for="product_num" class="form-label">庫存數量</label>
                <input type="text" class="form-control" name="product_num">
            </div>

            <div class="form-element my-4">
                <label for="product_desc" class="form-label">商品描述</label>
                <textarea name="product_desc" id="" class="form-control"></textarea>
            </div>

            <div class="form-element my-4">
                <label for="product_pic" class="form-label">上傳圖片</label>
                <input type="file" name="product_pic" id="product_pic" class="form-control" accept="image/*" required>
            </div>

            <div class="form-element my-4">
                <input type="submit" name="create" value="ADD Product" class="btn btn-primary">
            </div>
        </form>
    </div>
</body>

</html>