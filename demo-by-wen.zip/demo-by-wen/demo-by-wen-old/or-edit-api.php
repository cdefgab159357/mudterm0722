<?php
include('connect.php');
if (isset($_POST["edit"])) {
    $product_name = mysqli_real_escape_string($conn, $_POST["product_name"]);
    $product_type = mysqli_real_escape_string($conn, $_POST["product_type"]);
    $product_price = mysqli_real_escape_string($conn, $_POST["product_price"]);
    $product_num = mysqli_real_escape_string($conn, $_POST["product_num"]);
    $product_desc = mysqli_real_escape_string($conn, $_POST["product_desc"]);
    $product_id = mysqli_real_escape_string($conn, $_POST["product_id"]);
    
    $sqlUpdate = "UPDATE books SET 
    product_name = '$product_name', 
    product_type = '$product_type', 
    product_price = '$product_price', 
    product_num = '$product_num', 
    product_desc = '$product_desc' 
    WHERE product_id = '$product_id' ";

    if (mysqli_query($conn, $sqlUpdate)) {
        session_start();
        $_SESSION["edit"] = "Product Updated Successfully!";
        header("Location:index_pro.php");
    } else {
        die("Something went wrong");
    }
}
