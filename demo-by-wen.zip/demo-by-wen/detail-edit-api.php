<?php
include('connect.php');
if (isset($_POST["edit"])) {
    $product_order_detail_id = mysqli_real_escape_string($conn, $_POST["product_order_detail_id"]);
    $product_order_id = mysqli_real_escape_string($conn, $_POST["product_order_id"]);
    $product_id = mysqli_real_escape_string($conn, $_POST["product_id"]);
    $product_name = mysqli_real_escape_string($conn, $_POST["product_name"]);
    $quantity = mysqli_real_escape_string($conn, $_POST["quantity"]);
    
    // 更新的表格名稱應該是 `orderlist_detail`
    $sqlUpdate = "UPDATE orderlist_detail SET 
        product_order_id = '$product_order_id',
        product_id = '$product_id', 
        product_name = '$product_name', 
        quantity = '$quantity' 
        WHERE product_order_detail_id = '$product_order_detail_id'";

    if (mysqli_query($conn, $sqlUpdate)) {
        session_start();
        $_SESSION["edit"] = "修改成功 !";
        header("Location: orderlist-detail.php"); // 修正重定向的URL
        exit(); // 確保 header 重定向生效
    } else {
        die("出現錯誤 " . mysqli_error($conn)); // 更具體的錯誤訊息
    }
}
?>
