<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <title>Edit Product</title>
</head>

<body>
    <div class="container my-5">
        <header class="d-flex justify-content-between my-4">
            <h1>編輯訂單詳情</h1>
            <div>
                <a href="orderlist_detail.php" class="btn btn-primary">返回</a> <!-- 修改返回頁面的URL -->
            </div>
        </header>
        <form action="detail-edit-api.php" method="post">
            <?php
            if (isset($_GET['product_order_detail_id'])) { // 修正變數名稱
                include("connect.php");
                mysqli_set_charset($conn, 'utf8mb4');
                
                $product_order_detail_id = mysqli_real_escape_string($conn, $_GET['product_order_detail_id']); // 使用 mysqli_real_escape_string 函數處理變數
                $sql = "SELECT * FROM orderlist_detail WHERE product_order_detail_id='$product_order_detail_id'"; // 修正SQL查詢              
                $result = mysqli_query($conn, $sql);
                if ($result && mysqli_num_rows($result) > 0) {
                    $row = mysqli_fetch_array($result);
            ?>
                <div class="form-element my-4">
                    <label for="product_order_detail_id" class="form-label">訂單詳情</label>
                    <input type="text" class="form-control" name="product_order_detail_id" value="<?php echo htmlspecialchars($row["product_order_detail_id"]); ?>" readonly> <!-- 訂單編號設為只讀 -->
                </div>
<!-- 
                <div class="form-element my-4">
                    <label for="product_order_id" class="form-label">訂單編號</label>
                    <input type="text" class="form-control" name="product_order_id" value="<?php echo htmlspecialchars($row["product_order_id"]); ?>" readonly> <!-- 訂單編號設為只讀 -->
                </div>

                <div class="form-element my-4">
                    <label for="product_id" class="form-label">商品編號</label>
                    <input type="text" class="form-control" name="product_id" value="<?php echo htmlspecialchars($row["product_id"]); ?>">
                </div>

                <div class="form-element my-4">
                    <label for="product_name" class="form-label">商品名稱</label>
                    <input type="text" class="form-control" name="product_name" value="<?php echo htmlspecialchars($row["product_name"]); ?>">
                </div>

                <div class="form-element my-4">
                    <label for="quantity" class="form-label">訂購數量</label>
                    <input type="number" name="quantity" class="form-control" value="<?php echo htmlspecialchars($row["quantity"]); ?>"> <!-- 使用 input type="number" -->
                </div>
                 -->
                <input type="hidden" value="<?php echo htmlspecialchars($product_order_detail_id); ?>" name="product_order_detail_id"> <!-- 修正隱藏欄位名稱 -->

                <div class="form-element my-4">
                    <input type="submit" name="edit" value="確定編輯" class="btn btn-primary">
                </div>
            <?php
                } else {
                    echo "<h3>訂單不存在</h3>";
                }
            } else {
                echo "<h3>訂單不存在</h3>";
            }
            ?>

        </form>
    </div>
</body>

</html>
