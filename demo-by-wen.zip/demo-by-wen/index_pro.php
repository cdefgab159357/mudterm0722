<?php
session_start();

include('connect.php');

// 設置 MySQL 連接的編碼
mysqli_set_charset($conn, 'utf8mb4');

// 設置每頁顯示的數量
$limit = 10;

// 獲取當前頁面
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = $page > 0 ? $page : 1;

// 計算偏移量
$offset = ($page - 1) * $limit;

// 獲取總記錄數
$sqlCount = "SELECT COUNT(*) as total FROM books";
$resultCount = mysqli_query($conn, $sqlCount);
$rowCount = mysqli_fetch_assoc($resultCount);
$totalRecords = $rowCount['total'];
$totalPages = ceil($totalRecords / $limit);

// 查詢當前頁面的數據
$sqlSelect = "SELECT * FROM books LIMIT $limit OFFSET $offset";
$result = mysqli_query($conn, $sqlSelect);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

    <link rel="stylesheet" href="style.css">
    <title>Product List</title>
    <style>
        
        table td,
    table th {
      background-color: #fff;
      vertical-align: middle;
      text-align: right;
      padding: 20px !important;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Franklin Gothic Medium", "Arial Narrow", Arial, sans-serif;
    }

    body {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background: lightslategray;
    }

    ul.navcolor {
      position: relative;
      transform: skewY(-15deg);
      margin-left: 100px;
    }

    ul.navcolor li {
      position: relative;
      list-style: none;
      width: 200px;
      background: #3e3f46;
      padding: 15px;
      z-index: var(--i);
      transition: 0.3s;
    }

    ul.navcolor li:hover {
      background: #00E3E3;
      transform: translateX(-30px);
    }

    .li2:hover {
      background: #00E3E3;
      transform: translateX(30px);
    }

    ul.navcolor li::before {
      content: "  ";
      position: absolute;
      top: 0;
      left: -40px;
      width: 40px;
      height: 100%;
      background: #2e3133;
      transform-origin: right;
      transform: skewY(45deg);
    }

    ul.navcolor li:hover::before {
      background: #1f5378;
    }

    ul.navcolor li::after {
      content: "  ";
      position: absolute;
      top: -40px;
      left: 0;
      width: 100%;
      height: 40px;
      background: #35383e;
      transform-origin: bottom;
      transform: skewX(45deg);
      transition: 0.5s;
    }

    ul.navcolor li:hover::after {
      background-color: #2982b9;
    }

    ul.navcolor li a {
      text-decoration: none;
      color: #999;
      display: block;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      transition: 0.5s;
    }

    ul.navcolor li:hover a {
      color: #fff;
    }

    /* ul li:last-child::after {
      box-shadow: -100px 100px 20px rgba(0, 0, 0, 0.5);
    } */
    </style>
</head>

<body>
    <ul class="fixed-top navcolor">
        <li style="--i:4"><a href="pro-add.php">新增商品</a></li>
        <li style="--i:3"><a href="index_pro.php">商品列表</a></li>
        <li style="--i:2"><a href="orderlist.php">訂單編號</a></li>
        <li style="--i:1"><a href="orderlist-detail.php">訂單詳情</a></li>
    </ul>

    <div class="container my-4">
        <header class="d-flex justify-content-between my-4">
            <h1>商品列表</h1>
            <div>
                <a href="pro-add.php" class="btn btn-primary">新增商品</a>
            </div>
        </header>

        <form action="search.php" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="輸入搜尋關鍵字" name="keyword">
                <button class="btn btn-primary" type="submit">搜尋</button>
            </div>
        </form>

        <?php
        
        if (isset($_SESSION["create"])) {
            echo '<div class="alert alert-success">' . $_SESSION["create"] . '</div>';
            unset($_SESSION["create"]);
        }
        if (isset($_SESSION["edit"])) {
            echo '<div class="alert alert-success">' . $_SESSION["edit"] . '</div>';
            unset($_SESSION["edit"]);
        }
        if (isset($_SESSION["delete"])) {
            echo '<div class="alert alert-success">' . $_SESSION["delete"] . '</div>';
            unset($_SESSION["delete"]);
        }
        ?>

        <table class="table table-bordered bg-success p-2 text-white bg-opacity-10">
            <thead>
                <tr>
                    <th>商品編號</th>
                    <th>商品名稱</th>
                    <th>商品類型</th>
                    <th>商品價格</th>
                    <th>庫存數量</th>
                    <th>商品描述</th>
                    <th>建立時間</th>
                    <th>操作按鈕</th>
                </tr>
            </thead>
            <tbody>
                
                <?php while ($data = mysqli_fetch_array($result)) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($data['product_id']); ?></td>
                        <td><?php echo htmlspecialchars($data['product_name']); ?></td>
                        <td><?php echo htmlspecialchars($data['product_type']); ?></td>
                        <td><?php echo htmlspecialchars($data['product_price']); ?></td>
                        <td><?php echo htmlspecialchars($data['product_num']); ?></td>
                        <td><?php echo htmlspecialchars($data['product_desc']); ?></td>
                        <td><?php echo htmlspecialchars($data['create_at']); ?></td>
                        <td>
                            <a href="pro-view.php?product_id=<?php echo urlencode($data['product_id']); ?>" class="btn btn-info">圖片</a>
                            <a href="pro-edit.php?product_id=<?php echo urlencode($data['product_id']); ?>" class="btn btn-warning">編輯</a>
                            <a href="pro-delete.php?product_id=<?php echo urlencode($data['product_id']); ?>" class="btn btn-danger">刪除</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <nav aria-label="Page navigation">
            <ul class="pagination pagination-custom">
                <?php if ($page > 1) { ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                <?php } ?>
                <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php } ?>
                <?php if ($page < $totalPages) { ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                <?php } ?>
            </ul>
        </nav>
    </div>
</body>

</html>