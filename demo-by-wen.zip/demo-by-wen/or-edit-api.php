<?php
include('connect.php');
if (isset($_POST["edit"])) {
    $product_order_id = mysqli_real_escape_string($conn, $_POST["product_order_id"]);
    $order_date = mysqli_real_escape_string($conn, $_POST["order_date"]);
    $product_payment = mysqli_real_escape_string($conn, $_POST["product_payment"]);
    $deliver_status = mysqli_real_escape_string($conn, $_POST["deliver_status"]);
    $deliver_address = mysqli_real_escape_string($conn, $_POST["deliver_address"]); // 修正變數名稱
    
    $sqlUpdate = "UPDATE orderlist SET 
    product_order_id = '$product_order_id', 
    order_date = '$order_date', 
    product_payment = '$product_payment', 
    deliver_status = '$deliver_status', 
    deliver_address = '$deliver_address' 
    WHERE product_order_id = '$product_order_id'"; // 修正變數名稱

    if (mysqli_query($conn, $sqlUpdate)) {
        session_start();
        $_SESSION["edit"] = "修改成功 !";
        header("Location: orderlist.php"); // 修正重定向的URL
    } else {
        die("出現錯誤 " . mysqli_error($conn)); // 更具體的錯誤訊息
    }
}
