<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <title>Edit Product</title>
</head>

<body>
    <div class="container my-5">
        <header class="d-flex justify-content-between my-4">
            <h1>編輯訂單</h1>
            <div>
            <a href="orderlist.php" class="btn btn-primary">返回</a> <!-- 修改返回頁面的URL -->
            </div>
        </header>
        <form action="or-edit-api.php" method="post">
            <?php

if (isset($_GET['product_order_id'])) { // 修正變數名稱
                include("connect.php");

                // mysqli_set_charset($conn, 'utf8mb4');
                
                $product_order_id = $_GET['product_order_id']; // 修正變數名稱
                $sql = "SELECT * FROM orderlist WHERE product_order_id='$product_order_id'"; // 修正SQL查詢              
                $result = mysqli_query($conn, $sql);
                $row = mysqli_fetch_array($result);
            ?>
                <div class="form-element my-4">
                    <label for="product_order_id" class="form-label">訂單編號</label>
                    <input type="text" class="form-control" name="product_order_id" value="<?php echo $row["product_order_id"]; ?>" readonly> <!-- 訂單編號設為只讀 -->
                </div>

                <div class="form-element my-4">
    <label for="order_date" class="form-label">訂單日期</label>
    <?php
    // 確保日期格式為 YYYY-MM-DD
    $order_date = $row["order_date"];
    // 如果日期格式需要轉換
    try {
        $date = new DateTime($order_date);
        $formatted_date = $date->format('Y-m-d');
    } catch (Exception $e) {
        // 如果日期格式不正確，設定一個預設值或顯示錯誤
        $formatted_date = '';
    }
    ?>
    <input type="date" class="form-control" name="order_date" value="<?php echo htmlspecialchars($formatted_date); ?>"> <!-- 顯示訂單日期 -->
</div>


                <div class="form-element my-4">
                    <label for="product_payment" class="form-label">付款方式</label>
                    <input type="text" class="form-control" name="product_payment" value="<?php echo $row["product_payment"]; ?>">
                </div>

                <div class="form-element my-4">
                    <label for="deliver_status" class="form-label">配送狀態</label>
                    <input type="text" class="form-control" name="deliver_status" value="<?php echo $row["deliver_status"]; ?>">
                </div>

                <div class="form-element my-4">
                    <label for="deliver_address" class="form-label">寄送地址</label>
                    <textarea name="deliver_address" class="form-control"><?php echo $row["deliver_address"]; ?></textarea>
                </div>
                
                <input type="hidden"  value="<?php echo $product_id; ?>" name="product_id">

                <div class="form-element my-4">
                    <input type="submit" name="edit" value="確定編輯" class="btn btn-primary">
                </div>
            <?php
            } else {
                echo "<h3>訂單不存在</h3>";
            }
            ?>

        </form>


    </div>
</body>

</html>