<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <title>Edit Product</title>
</head>

<body>
    <div class="container my-5">
        <header class="d-flex justify-content-between my-4">
            <h1>產品編輯</h1>
            <div>
                <a href="index_pro.php" class="btn btn-primary">返回</a>
            </div>
        </header>
        <form action="pro-edit-api.php" method="post" enctype="multipart/form-data">
        <?php

            if (isset($_GET['product_id'])) {
                include("connect.php");

                // 設置 MySQL 連接的編碼
mysqli_set_charset($conn, 'utf8mb4');

                $product_id = $_GET['product_id'];
                $sql = "SELECT * FROM books WHERE product_id=$product_id";
                $result = mysqli_query($conn, $sql);
                $row = mysqli_fetch_array($result);
            ?>
                <div class="form-element my-4">
                    <label for="product_name" class="form-label">商品名稱</label>
                    <input type="text" class="form-control" name="product_name" value="<?php echo $row["product_name"]; ?>">
                </div>

                <div class="form-element my-4">
                    <label for="product_type" class="form-label">商品類型</label>
                    <select name="product_type" id="" class="form-control">
                        <option value="">Select Book Type:</option>
                        <option value="商品A" <?php if ($row["product_type"] == "商品A") {echo "selected";} ?>>商品A</option>
                        <option value="商品B" <?php if ($row["product_type"] == "商品B") {echo "selected";} ?>>商品B</option>
                        <option value="商品C" <?php if ($row["product_type"] == "商品C") {echo "selected";} ?>>商品C</option>
                        <option value="商品D" <?php if ($row["product_type"] == "商品D") {echo "selected";} ?>>商品D</option>
                    </select>
                </div>

                <div class="form-element my-4">
                    <label for="product_price" class="form-label">商品價格</label>
                    <input type="text" class="form-control" name="product_price" value="<?php echo $row["product_price"]; ?>">
                </div>

                <div class="form-element my-4">
                    <label for="product_num" class="form-label">庫存數量</label>
                    <input type="text" class="form-control" name="product_num" value="<?php echo $row["product_num"]; ?>">
                </div>

                <div class="form-element my-4">
                    <label for="product_desc" class="form-label">商品描述</label>
                    <textarea name="product_desc" class="form-control"><?php echo $row["product_desc"]; ?></textarea>
                </div>
                
                <div class="form-element my-4">
                <label for="product_pic" class="form-label">上傳圖片</label>
                <input type="file" name="product_pic" id="product_pic" class="form-control" accept="image/*" required>

                <img src="" alt="" id="myImg" width="300px">

                <script>
                    const field = document.forms[0].product_pic;

                    field.addEventListener("change", (e) => {
                        console.log(field.files[0]);
                        const url = URL.createObjectURL(field.files[0]);
                        myImg.src = url;
                    });
                </script>
            </div>

                <input type="hidden"  value="<?php echo $product_id; ?>" name="product_id">

                <div class="form-element my-4">
                    <input type="submit" name="edit" value="確定編輯" class="btn btn-primary">
                </div>
            <?php
            } else {
                echo "<h3>Product Does Not Exist</h3>";
            }
            ?>

        </form>


    </div>
</body>

</html>